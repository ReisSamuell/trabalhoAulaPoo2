
package encapsulation;

/**
 * Classe representando um pato.
 */
public class Pato {
    public Boolean asas = true;
    public Boolean bico = true;
    public Boolean penas = true;

    public void bicar() {
        System.out.println("Pode bicar");
    }

    public void nadar() {
        System.out.println("Pode nadar");
    }

    public void voar() {
        System.out.println("Pode voar");
    }
}
