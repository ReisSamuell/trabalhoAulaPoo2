
package encapsulation;

public class Main {
    public static void main(String[] args) {
        Pinguim pinguim = new Pinguim();
        pinguim.bicar();
        pinguim.setBico(false);
        pinguim.bicar();

        Pato pato = new Pato();
        pato.bico = false;
    }
}
