
package encapsulation;

/**
 * Classe representando um pinguim.
 */
public class Pinguim {
    private Boolean asas = true;
    private Boolean bico = true;
    private Boolean penas = true;

    public void setBico(Boolean bico) {
        this.bico = bico;
    }

    public void bicar() {
        if (bico.equals(true)) {
            System.out.println("Um Pinguim pode bicar");
        } else {
            System.out.println("Um Pinguim não pode bicar");
        }
    }

    public void nadar() {
        System.out.println("Pode nadar");
    }
}
