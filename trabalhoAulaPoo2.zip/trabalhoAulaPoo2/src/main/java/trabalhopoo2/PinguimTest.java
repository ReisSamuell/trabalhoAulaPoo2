package trabalhopoo2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PinguimTest {

    private Pinguim pinguim;

    @BeforeEach
    void setUp() {
        pinguim = new Pinguim();
    }

    @Test
    void testBicarComBicoAtivo() {
        pinguim.bico = true;
        pinguim.bicar();
        assertTrue(pinguim.bico); // Verifica que bico está ativo
    }

    @Test
    void testBicarSemBico() {
        pinguim.bico = false;
        pinguim.bicar();
        assertFalse(pinguim.bico); // Verifica que bico está desativado
    }

    @Test
    void testNadar() {
        // Ainda sem lógica implementada, apenas estrutura de teste
        assertDoesNotThrow(() -> pinguim.nadar());
    }
}
