package trabalhopoo2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PatoTest {

    private Pato pato;

    @BeforeEach
    void setUp() {
        pato = new Pato();
    }

    @Test
    void testBicar() {
        assertDoesNotThrow(() -> pato.bicar());
    }

    @Test
    void testNadar() {
        assertDoesNotThrow(() -> pato.nadar());
    }

    @Test
    void testVoar() {
        assertDoesNotThrow(() -> pato.voar());
    }
}
