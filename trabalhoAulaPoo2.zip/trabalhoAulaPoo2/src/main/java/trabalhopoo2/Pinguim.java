/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalhopoo2;

/**
 *
 * @author Pc
 */
public class Pinguim {
    // Propriedades ou atributos do objeto Pinguim
		Boolean asas = true;
		Boolean bico = true;
		Boolean penas = true;
		
		// Métodos do objeto Pinguim
		public void bicar() {
			if(bico.equals(true)) {
				System.out.println("Um Pinguim pode bicar");
			} else {
				System.out.println("Um Pinguim não pode bicar");
			}
		}
		
		public void nadar() {
		//Ação ...
		}
}
