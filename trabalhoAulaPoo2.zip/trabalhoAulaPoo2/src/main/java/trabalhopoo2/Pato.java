/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalhopoo2;

/**
 *
 * @author Pc
 */
public class Pato {
    // Propriedades ou atributos do objeto Pato
		Boolean asas = true;
		Boolean bico = true;
		Boolean penas = true;
	
		// Métodos do objeto Pato
		public void bicar() {
		//Ação ...
		}
		
		public void nadar() {
		//Ação ...
		}
	
		public void voar() {
		//Ação ...
		}
	}

