
package polymorphism;

/**
 * Interface para aves que voam.
 */
public interface AveVoa {
    default void voar() {
        System.out.println("Pode voar");
    }
}
