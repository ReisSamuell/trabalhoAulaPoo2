
package polymorphism;

public class Main {
    public static void main(String[] args) {
        Pinguim pinguim = new Pinguim();
        pinguim.bicar();
        pinguim.setBico(false);
        pinguim.nadar();
        pinguim.bicar();

        Pato pato = new Pato();
        pato.voar();
        pato.nadar();
        pato.bicar();
        pato.setBico(false);
        pato.bicar();
    }
}
