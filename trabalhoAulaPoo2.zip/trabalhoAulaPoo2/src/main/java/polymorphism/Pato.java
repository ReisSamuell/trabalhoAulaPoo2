
package polymorphism;

/**
 * Classe representando um pato.
 */
public class Pato extends Aves implements AveNaoVoa, AveVoa {
    @Override
    public void setBico(Boolean bico) {
        this.bico = bico;
    }

    @Override
    public void bicar() {
        if (this.bico.equals(true)) {
            System.out.println("Um Pato pode bicar");
        } else {
            System.out.println("Um Pato não pode bicar");
        }
    }
}
