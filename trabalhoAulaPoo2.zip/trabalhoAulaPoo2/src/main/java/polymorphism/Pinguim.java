
package polymorphism;

/**
 * Classe representando um pinguim.
 */
public class Pinguim extends Aves implements AveNaoVoa {
    @Override
    public void setBico(Boolean bico) {
        this.bico = bico;
    }

    @Override
    public void bicar() {
        if (this.bico.equals(true)) {
            System.out.println("Um Pinguim pode bicar");
        } else {
            System.out.println("Um Pinguim não pode bicar");
        }
    }
}
