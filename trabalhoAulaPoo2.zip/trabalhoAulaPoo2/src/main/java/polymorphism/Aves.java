
package polymorphism;

/**
 * Classe base para aves.
 */
public class Aves {
    private Boolean asas = true;
    protected Boolean bico = true;
    private Boolean penas = true;

    public void setBico(Boolean bico) {
        this.bico = bico;
    }

    public void bicar() {
        if (this.bico.equals(true)) {
            System.out.println("Pode bicar");
        } else {
            System.out.println("Não pode bicar");
        }
    }
}
