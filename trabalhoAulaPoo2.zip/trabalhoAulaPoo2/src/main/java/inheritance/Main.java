
package inheritance;

public class Main {
    public static void main(String[] args) {
        Pinguim pinguim = new Pinguim();
        pinguim.bicar();
        pinguim.setBico(false);
        pinguim.nadar();

        Pato pato = new Pato();
        pato.voar();
        pato.nadar();
    }
}
