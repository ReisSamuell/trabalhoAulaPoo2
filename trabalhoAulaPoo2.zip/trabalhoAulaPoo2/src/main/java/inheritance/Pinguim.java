
package inheritance;

/**
 * Classe representando um pinguim.
 */
public class Pinguim extends Aves implements AveNaoVoa {}
