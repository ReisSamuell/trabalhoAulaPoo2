
package inheritance;

/**
 * Classe representando um pato.
 */
public class Pato extends Aves implements AveNaoVoa, AveVoa {}
