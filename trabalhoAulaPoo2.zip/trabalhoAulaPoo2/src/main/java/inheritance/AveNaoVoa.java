
package inheritance;

/**
 * Interface para aves que não voam.
 */
public interface AveNaoVoa {
    default void nadar() {
        System.out.println("Pode nadar");
    }
}
